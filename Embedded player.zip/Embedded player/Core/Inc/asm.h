

#ifndef INC_ASM_H_
#define INC_ASM_H_

#include "display.h"

void memset_word(void *, int, unsigned int);
void memset_halfword(void *, int, unsigned int);
void memset_byte(void *, int, unsigned int);

#endif /* INC_ASM_H_ */
