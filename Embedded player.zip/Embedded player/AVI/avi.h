
#ifndef AVI_H_
#define AVI_H_


#include "display.h"

//----------------------Audio DAC Configuration (User Settings)------------------------
#define AudioDAC_I2S		SPI3				//spi, on the basis of which i2s is used for dac
#define AudioDAC_DMA		DMA1				//dma controller serving dac
#define AudioDAC_DMA_Stream	LL_DMA_STREAM_5		//dma controller thread serving dac
#define AudioDAC_IRQn		DMA1_Stream5_IRQn	//interruption in the DMA thread serving dac
//----------------------------------------------------------------------------------------------

void PlayAVI(char *dir, char *fname, LCD_Handler *lcd, uint16_t x, uint16_t y, uint16_t win_wdt, uint16_t win_hgt);
void AVIIntro(LCD_Handler *lcd);

#endif /* AVI_H_ */
