

#ifndef MP3_CALLBACK_H_
#define MP3_CALLBACK_H_

#include "ff.h"
#include "player.h"
#include "mp3dec.h"

typedef struct {
	HMP3Decoder mp3Decoder;
	MP3FrameInfo mp3FrameInfo;
	FSIZE_t startPosData;
	uint8_t inbuffer[MAINBUF_SIZE];
} Player_client_mp3;

PlayerReadHeaderStatus mp3_read_header_callback (Player *player);
PlayerStartPlayStatus  mp3_start_play_callback (Player *player);
PlayerUpdateStatus     mp3_update_play_callback (Player *player);
PlayerStopStatus       mp3_stop_callback (Player *player);

#endif /* MP3_CALLBACK_H_ */
