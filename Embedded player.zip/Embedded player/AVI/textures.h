

#ifndef INC_TEXTURES_H_
#define INC_TEXTURES_H_

#include "microgl2d.h"

extern const MGL_IMAGE image_avatar;
extern const MGL_IMAGE image_volume;
extern const MGL_IMAGE image_x;

#endif /* INC_TEXTURES_H_ */
